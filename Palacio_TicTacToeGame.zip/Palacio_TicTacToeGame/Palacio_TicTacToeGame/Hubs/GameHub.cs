﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace TicTacToeGame.Hubs
{
    public class GameHub : Hub
    {
        public async Task MakeMove(int cellIndex, string player)
        {
            await Clients.Others.SendAsync("ReceiveMove", cellIndex, player);
        }

        public async Task RestartGame()
        {
            await Clients.All.SendAsync("GameRestarted");
        }
    }
}
