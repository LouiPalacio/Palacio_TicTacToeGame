﻿using System;
using System.Linq;

namespace TicTacToeGame.Models
{
    public class TicTacToeAI
    {
        public int GetBestMove(string[] board)
        {
            int bestScore = int.MinValue;
            int bestMove = -1;

            for (int i = 0; i < board.Length; i++)
            {
                if (board[i] == "")
                {
                    board[i] = "O"; // AI makes a move
                    int score = Minimax(board, false);
                    board[i] = ""; // Undo move

                    if (score > bestScore)
                    {
                        bestScore = score;
                        bestMove = i;
                    }
                }
            }

            return bestMove;
        }

        private int Minimax(string[] board, bool isMaximizing)
        {
            string winner = CheckWinner(board);
            if (winner == "O") return 1;
            if (winner == "X") return -1;
            if (!board.Contains("")) return 0; // Draw

            if (isMaximizing)
            {
                int bestScore = int.MinValue;
                for (int i = 0; i < board.Length; i++)
                {
                    if (board[i] == "")
                    {
                        board[i] = "O";
                        int score = Minimax(board, false);
                        board[i] = "";
                        bestScore = Math.Max(score, bestScore);
                    }
                }
                return bestScore;
            }
            else
            {
                int bestScore = int.MaxValue;
                for (int i = 0; i < board.Length; i++)
                {
                    if (board[i] == "")
                    {
                        board[i] = "X";
                        int score = Minimax(board, true);
                        board[i] = "";
                        bestScore = Math.Min(score, bestScore);
                    }
                }
                return bestScore;
            }
        }

        private string CheckWinner(string[] board)
        {
            int[][] winPatterns = {
                new int[] {0,1,2}, new int[] {3,4,5}, new int[] {6,7,8},
                new int[] {0,3,6}, new int[] {1,4,7}, new int[] {2,5,8},
                new int[] {0,4,8}, new int[] {2,4,6}
            };

            foreach (var pattern in winPatterns)
            {
                if (board[pattern[0]] != "" &&
                    board[pattern[0]] == board[pattern[1]] &&
                    board[pattern[1]] == board[pattern[2]])
                {
                    return board[pattern[0]];
                }
            }
            return null;
        }
    }
}
