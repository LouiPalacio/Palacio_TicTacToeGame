﻿using Microsoft.AspNetCore.Mvc;
using TicTacToeGame.Models;

namespace TicTacToeGame.Controllers
{
    public class GameController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult GetAIMove([FromBody] string[] board)
        {
            TicTacToeAI ai = new TicTacToeAI();
            int bestMove = ai.GetBestMove(board);
            return Json(new { move = bestMove });
        }
    }
}
